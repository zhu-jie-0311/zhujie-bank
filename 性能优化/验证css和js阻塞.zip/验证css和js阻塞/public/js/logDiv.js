const div = document.querySelector('div');
console.log(div);


